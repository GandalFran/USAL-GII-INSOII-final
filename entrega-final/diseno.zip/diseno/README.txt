*Capturas de todos los diagramas del documento se pueden encontrar en el directorio /media
*Los proyectos completos de visual paradigm con todos los diagramas se encuentra en el directorio /visual-paradigm-diagrams
*Se presentan documentos tecnicos tanto en formato .pdf como .docx
*Por motivos de tama�o el diagrama de clases del dise�o no se ha podido incluir dentro del documento, existe una referencia al mismo en el archivo /class-diagram.png
